class DeleteTable < ActiveRecord::Migration
  def change
    drop_table :examination_types
    drop_table :examination_modules
  end
end
