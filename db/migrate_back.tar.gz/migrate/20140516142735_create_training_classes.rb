class CreateTrainingClasses < ActiveRecord::Migration
  def change
    create_table :training_classes do |t|
      t.string :name
      t.string :code
      t.date :start_date
      t.date :end_date

      t.timestamps
    end
  end
end
