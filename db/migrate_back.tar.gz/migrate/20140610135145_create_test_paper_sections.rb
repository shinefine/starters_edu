class CreateTestPaperSections < ActiveRecord::Migration
  def change
    create_table :test_paper_sections do |t|
      t.string :name
      t.belongs_to :test_paper
      t.integer :question_number
      t.string :course_type

      t.timestamps
    end
  end
end
