class CreateStudentsTestPapers < ActiveRecord::Migration
  def change
    create_table :students_test_papers,id:false do |t|
      t.belongs_to :student
      t.belongs_to :test_paper
    end
  end
end
