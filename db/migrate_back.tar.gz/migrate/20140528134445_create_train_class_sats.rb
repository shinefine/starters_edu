class CreateTrainClassSats < ActiveRecord::Migration
  def change
    create_table :train_class_sats do |t|

      t.string :name
      t.string :code
      t.date :start_date
      t.date :end_date
      t.integer  :writing_teacher_id
      t.integer  :cr_teacher_id
      t.integer  :master_teacher_id
      t.integer  :math_teacher_id

      t.timestamps
    end
  end
end
