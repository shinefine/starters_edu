class CreateStudents < ActiveRecord::Migration
  def change
    create_table :students do |t|
      t.string :name
      t.string :more_info
      t.string :code

      t.timestamps
    end
  end
end
