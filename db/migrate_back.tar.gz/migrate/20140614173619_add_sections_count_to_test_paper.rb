class AddSectionsCountToTestPaper < ActiveRecord::Migration
  def change
    add_column :test_papers, :test_paper_sections_count, :integer, :default => 0
  end
end
