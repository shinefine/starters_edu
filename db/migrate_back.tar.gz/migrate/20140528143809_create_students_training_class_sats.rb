class CreateStudentsTrainingClassSats < ActiveRecord::Migration
  def change
    create_table :students_train_class_sats,id:false do |t|
      t.belongs_to :student
      t.belongs_to :train_class_sat
    end
  end

end
