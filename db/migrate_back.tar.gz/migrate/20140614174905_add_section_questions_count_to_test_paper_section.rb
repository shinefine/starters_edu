class AddSectionQuestionsCountToTestPaperSection < ActiveRecord::Migration
  def change
    #add_column :test_paper_sections, :section_questions_count, :integer, :default => 0

    change_table :test_paper_sections do |t|
      t.remove :question_number #移除列
      t.integer :section_questions_count, :default=>0
    end

  end
end
