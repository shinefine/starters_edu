class ChangeTrainingClasses < ActiveRecord::Migration
  def change
    change_table :training_classes do |t|
      #t.remove :description, :name #移除列
      #t.string :part_number  #加列
      #t.index :part_number   #加索引
      #t.rename :upccode, :upc_code #改列名
      t.integer  :master_teacher_id

      t.integer  :sat_writing_teacher_id
      t.integer  :sat_cr_teacher_id
      t.integer  :sat_math_teacher_id
    end


  end
end
