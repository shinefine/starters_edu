class CreateScoreDetails < ActiveRecord::Migration
  def change

      create_table :score_details do |t|
        t.string :answer_result
        t.integer :score_number
        t.belongs_to :simulate_test_score
        t.belongs_to :section_question
      t.timestamps
    end
  end
end
