class CreateSimulateTests < ActiveRecord::Migration
  def change
    create_table :simulate_tests do |t|
      t.integer :training_class_id
      t.integer :test_paper_id
      t.date :TestDate

      t.timestamps
    end
  end
end
