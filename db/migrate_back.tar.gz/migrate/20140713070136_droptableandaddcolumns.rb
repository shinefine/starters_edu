class Droptableandaddcolumns < ActiveRecord::Migration
  def change
    drop_table :students_train_class_sats
    add_column :simulate_test_scores, :tofel_listen_score, :integer
    add_column :simulate_test_scores, :tofel_talk_score, :integer
    add_column :simulate_test_scores, :tofel_read_score, :integer
    add_column :simulate_test_scores, :tofel_write_score, :integer


  end
end
