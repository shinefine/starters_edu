class CreateTestPapers < ActiveRecord::Migration
  def change
    create_table :test_papers do |t|
      t.string :name
      t.belongs_to :examination_type
      t.timestamps
    end
  end
end
