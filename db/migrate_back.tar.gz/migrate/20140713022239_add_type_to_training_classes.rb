class AddTypeToTrainingClasses < ActiveRecord::Migration
  def change
    add_column :training_classes, :exam_type, :string, :default => "SAT"
  end
end
