class CreateSimulateTestScores < ActiveRecord::Migration
  def change
    create_table :simulate_test_scores do |t|
      t.belongs_to :simulate_test
      t.belongs_to :student
      t.integer :cr_score
      t.integer :math_score
      t.integer :writing_score
      t.integer :essay_writing_score
      t.integer :final_score

      t.timestamps
    end
  end
end
