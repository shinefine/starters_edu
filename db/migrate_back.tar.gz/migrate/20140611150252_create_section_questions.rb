class CreateSectionQuestions < ActiveRecord::Migration
  def change
    create_table :section_questions do |t|
      t.integer :index_number
      t.integer :difficulty
      t.belongs_to :test_paper_section

      t.timestamps
    end
  end
end
