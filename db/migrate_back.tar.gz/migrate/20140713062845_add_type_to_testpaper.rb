class AddTypeToTestpaper < ActiveRecord::Migration
  def change
    add_column :test_papers, :exam_type, :string, :default => "SAT"
    remove_column :test_papers, :examination_type_id
  end
end
