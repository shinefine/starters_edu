class CreateTeachersTrainingClass < ActiveRecord::Migration
  def change
    create_table :teachers_training_classes do |t|
      t.belongs_to :teacher
      t.belongs_to :training_class
      t.string :type
    end
  end
end
