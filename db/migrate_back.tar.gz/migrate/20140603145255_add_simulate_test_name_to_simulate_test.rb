class AddSimulateTestNameToSimulateTest < ActiveRecord::Migration
  def change
    add_column :simulate_tests, :name, :string
  end
end
