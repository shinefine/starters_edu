class CreateHomeworks < ActiveRecord::Migration
  def change
    create_table :homeworks do |t|
      t.string :title
      t.date :distribution_date
      t.string :type
      t.belongs_to :teacher
      t.belongs_to :test_paper
      t.belongs_to :training_class

      t.timestamps
    end
  end
end
