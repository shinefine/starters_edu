class RenametablesimulateTest < ActiveRecord::Migration


  def change
    change_table :simulate_tests do |t|
      #t.remove :description, :name #移除列
      #t.string :part_number  #加列
      #t.index :part_number   #加索引
      t.rename :TestDate, :test_date #改列名
    end

  end
end

