class CreateExaminationModules < ActiveRecord::Migration
  def change
    create_table :examination_modules do |t|
      t.string :name
      t.integer :total_score
      t.belongs_to :examination_type
      t.timestamps
    end
  end
end
